//
//  AllGroupCell.swift
//  VKontakte
//
//  Created by DenKennedy on 21.02.2021.
//

import UIKit

class AllGroupCell: UITableViewCell {

    @IBOutlet weak var GroupName: UILabel!
    
    @IBOutlet weak var GroupImage: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
