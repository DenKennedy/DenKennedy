//
//  AllGroupController.swift
//  VKontakte
//
//  Created by DenKennedy on 21.02.2021.
//

import UIKit

class AllGroupController: UITableViewController, UISearchBarDelegate {

    let allGroups = [group1, group2, group3, group4, group5, group6]
    var filtredGroups: [allGroup]!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
        filtredGroups = allGroups
    }
    
    //MARK: - Table View Data Sours

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filtredGroups.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GroupCell", for: indexPath) as? AllGroupCell else { return UITableViewCell() }
        
        cell.GroupName.text = filtredGroups[indexPath.row].groupName
        cell.GroupImage.image = UIImage(named: filtredGroups[indexPath.row].groupImage)

        return cell
    }
    
    //MARK: - Search Bar Config
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filtredGroups = []
        
        if searchText == "" {
            
            filtredGroups = allGroups
        } else {
            for group in allGroups {
                if group.groupName.lowercased().contains(searchText.lowercased()) {
                    
                    filtredGroups.append(group)
                }
            }
        }
        self.tableView.reloadData()
    }
}
