//
//  CustimSegueForMyGroup.swift
//  VKontakte
//
//  Created by DenKennedy on 26.03.2021.
//

import UIKit

class CustomSegueForMyGroup: UIStoryboardSegue {
    
    override func perform() {
        let src = self.source
        
        let tableViewController = src as! AllGroupController
        let indexPath = tableViewController.tableView.indexPathForSelectedRow
        let cell = tableViewController.tableView.cellForRow(at: indexPath!) as! AllGroupCell
        print(cell.textLabel!.text ?? "")
        
        UIView.animate(withDuration: 0.5, // продолжительность
                       delay: 0.05,        // задерживать
                       usingSpringWithDamping: 0.1, // использование пружины
                       initialSpringVelocity: 0.3, // начальная скорость пружины
                       options: .curveEaseOut,
                       animations: {
                        cell.GroupImage.bounds = CGRect(x: 0, y: 0, width: 80, height: 80)}
                       ,completion: {_ in
                        super.perform()
        })
    }

}
