//
//  ViewController.swift
//  VKontakte
//
//  Created by DenKennedy on 06.02.2021.
//

import UIKit

class LoginFormController: UIViewController {

    @IBOutlet weak var LoginTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var ScrollView: UIScrollView!
        
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.showKeyboard), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.hiddenKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let hideKeyboardGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        ScrollView?.addGestureRecognizer(hideKeyboardGesture)
    }
    
    @objc func showKeyboard(notification: Notification) {
        
        let info = notification.userInfo! as NSDictionary
        let keyBoardSize = (info.value(forKey: UIResponder.keyboardFrameEndUserInfoKey) as! NSValue).cgRectValue.size
        let contInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: keyBoardSize.height, right: 0.0)
        
        self.ScrollView?.contentInset = contInsets
        ScrollView?.scrollIndicatorInsets = contInsets
    }
    
    @objc func hiddenKeyboard(notification: Notification) {
        
        let contInsets = UIEdgeInsets.zero
        ScrollView.contentInset = contInsets
        
    }
    
    @objc func hideKeyboard() {
        self.ScrollView?.endEditing(true)
    }
    
    func checkUserData() -> Bool {
        guard let login = LoginTextField.text,
              let password = PasswordTextField.text else {
            print("авторизация не пройдена")
            return false
        }
            
        if login == "admin" && password == "12345"{
            return true
        }
            return true
    }
    
    func loginError () {
        let alert = UIAlertController(title: "Error", message: "Не верный логин или пароль", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)

    }

   override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if checkUserData() {
            return true
        }
        loginError()
    return false
    
   }

@IBAction func LoginButtonPressed(_ sender: UIButton) {
    
   }
    
}


