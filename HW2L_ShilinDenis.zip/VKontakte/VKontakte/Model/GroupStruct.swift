//
//  GroupStruct.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

struct allGroup {
    var groupName: String
    var groupRules: String
    var groupUsersCount: Int
    var groupImage: String
    
}

var group1 = allGroup(groupName: "Музыка", groupRules: "Только музыка, никаких фильмов", groupUsersCount: 4553, groupImage: "Music")

var group2 = allGroup(groupName: "Кино", groupRules: "Только фильмы, никакой музыки", groupUsersCount: 4553, groupImage: "Cinema")

var group3 = allGroup(groupName: "Кошки", groupRules: "Вход по селедке", groupUsersCount: 4553, groupImage: "Cat")

var group4 = allGroup(groupName: "Собаки", groupRules: "Вход по косточке", groupUsersCount: 45593, groupImage: "Dog")

var group5 = allGroup(groupName: "Автомобили", groupRules: "Только машины", groupUsersCount: 4334, groupImage: "Car")

var group6 = allGroup(groupName: "Basketball", groupRules: "all about the best ball game", groupUsersCount: 5000, groupImage: "BasketballGroupImage")

