//
//  UserStruct.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

struct allUsers {
    var userNick: String
    var userFirstname: String
    var userLastname: String
    var userCountry: String
    var userCity: String
    var userAge: Int
    var userImage: String
    
    var userPhoto = [String]()
    
}


var user1 = allUsers(userNick: "Швед", userFirstname: "Алексей", userLastname: "Швед", userCountry: "Россия", userCity: "Москва", userAge: 32, userImage: "AvaShved", userPhoto: ["PhotoShved1", "PhotoShved2", "PhotoShved3"])

var user2 = allUsers(userNick: "McCollum", userFirstname: "Errick", userLastname: "McCollum", userCountry: "США", userCity: "Кантон", userAge: 33, userImage: "AvaMcCollum", userPhoto: ["PhotoMcCollum1", "PhotoMcCollum2", "PhotoMcCollum3"])

var user3 = allUsers(userNick: "JTimma", userFirstname: "Янис", userLastname: "Тимма", userCountry: "Латвия", userCity: "Краслава", userAge: 28, userImage: "AvaTimma", userPhoto: ["PhotoTimma1", "PhotoTimma2", "PhotoTimma3", "PhotoTimma4"])

var user4 = allUsers(userNick: "Карасев", userFirstname: "Сергей", userLastname: "Карасев", userCountry: "Россия", userCity: "Санкт-Петербург", userAge: 27, userImage: "AvaKarasev", userPhoto: ["PhotoKarasev1", "PhotoKarasev2"])

var user5 = allUsers(userNick: "Зайцев", userFirstname: "Вячеслав", userLastname: "Зайцев", userCountry: "Россия", userCity: "Москва", userAge: 31, userImage: "AvaZaitcev", userPhoto: ["PhotoZaitcev1", "PhotoZaitcev2", "PhotoZaitcev3"])

var user6 = allUsers(userNick: "Jovich", userFirstname: "Стефан", userLastname: "Йович", userCountry: "Сербия", userCity: "Ниш", userAge: 30, userImage: "AvaJovich", userPhoto: ["PhotoJovich1", "PhotoJovich2", "PhotoJovich3", "PhotoJovich4"])

var user7 = allUsers(userNick: "DeeBook", userFirstname: "Девин", userLastname: "Букер", userCountry: "США", userCity: "Гран-Рапидс", userAge: 30, userImage: "AvaBooker", userPhoto: ["PhotoBooker1", "PhotoBooker2", "PhotoBooker3", "PhotoBooker4"])

var user8 = allUsers(userNick: "Jordan", userFirstname: "Джордан", userLastname: "Мики", userCountry: "США", userCity: "Даллас", userAge: 26, userImage: "AvaMikki", userPhoto: ["PhotoMikki1", "PhotoMikki2", "PhotoMikki3"])

