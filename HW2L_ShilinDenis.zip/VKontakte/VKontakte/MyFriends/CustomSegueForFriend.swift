//
//  CustomSegueForFriend.swift
//  VKontakte
//
//  Created by DenKennedy on 25.03.2021.
//

import UIKit

class CustomSegueForFriend: UIStoryboardSegue {
    
    override func perform() {
        let src = self.source
        let dst = self.destination
        
        let tableViewController = src as! MyFriendController
        let indexPath = tableViewController.tableView.indexPathForSelectedRow
        let cell = tableViewController.tableView.cellForRow(at: indexPath!) as! MyFriendCell
        print(cell.textLabel!.text ?? "")
        
        UIView.animate(withDuration: 0.5, // продолжительность
                       delay: 0.05,        // задерживать
                       usingSpringWithDamping: 0.1, // использование пружины
                       initialSpringVelocity: 0.3, // начальная скорость пружины
                       options: .curveEaseOut,
                       animations: {
                        cell.ImageFriend?.bounds = CGRect(x: 0, y: 0, width: 75, height: 75)
                       }
                       ,completion: {
                        _ in src.navigationController?.pushViewController(dst, animated: true)
        })
    }
}
