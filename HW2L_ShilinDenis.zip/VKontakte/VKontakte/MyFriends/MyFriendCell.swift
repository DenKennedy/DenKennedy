//
//  MyFriendCell.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

class MyFriendCell: UITableViewCell {
    
    @IBOutlet weak var ImageFriend: UIImageView!
    
    @IBOutlet weak var ShadowLayer: UIImageView!
    
    @IBOutlet weak var FirstnameLabel: UILabel!
    @IBOutlet weak var LastnameLabel: UILabel!
    
    
    @IBInspectable var ShadowRadius: CGFloat = 0
    @IBInspectable var ShadowOpacity: Float = 0.0
    @IBInspectable var ShadowColor: UIColor = UIColor.black
        
    override func awakeFromNib() {
        super.awakeFromNib()
        
        backgroundColor = UIColor.clear
        
        ShadowLayer.layer.cornerRadius = self.ShadowLayer.frame.width / 2
        
        layer.shadowRadius = ShadowRadius
        layer.shadowColor = ShadowColor.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 10)
        layer.shadowOpacity = ShadowOpacity
        
        ImageFriend.layer.cornerRadius = self.ImageFriend.frame.width / 2
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
