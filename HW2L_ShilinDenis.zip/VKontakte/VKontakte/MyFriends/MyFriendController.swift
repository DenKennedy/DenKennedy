//
//  MyFriendController.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

class MyFriendController: UITableViewController, UISearchBarDelegate {
        
    @IBOutlet weak var searchBarFriends: UISearchBar!
    
    let myFriendsOld = [user1, user2, user3, user4, user5, user6, user7, user8]
    var filtredFriends: [allUsers]!
    
    var nameSectionsTitles = [String]()
    var nameDictionary = [String: [allUsers]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBarFriends.delegate = self
        //filtredFriends = myFriends
        
        //MARK: - sort friends alphabetically
        
        for friend in myFriendsOld {
            let keyName = String(friend.userFirstname.prefix(1))
            if var nameValues = nameDictionary[keyName] {
                nameValues.append(friend)
                nameDictionary[keyName] = nameValues
            } else {
                nameDictionary[keyName] = [friend]
            }
        }
                
        nameSectionsTitles = [String](nameDictionary.keys)
        nameSectionsTitles = nameSectionsTitles.sorted(by: { $0 < $1 })
    }
    
    
    //MARK: - Sorter and Search Bar Config
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filtredFriends = []
        
        if searchText == "" {
            
            filtredFriends = myFriendsOld
            
        } else {
            for friend in myFriendsOld {
                if friend.userFirstname.lowercased().contains(searchText.lowercased()) {
                    
                    filtredFriends.append(friend)
                }
            }
            for friend in myFriendsOld {
                if friend.userLastname.lowercased().contains(searchText.lowercased()) {
                    
                    filtredFriends.append(friend)
                }
            }
        }
        
        nameSectionsTitles = [String]()
        nameDictionary = [String: [allUsers]]()
        
        for friend in filtredFriends {
            let keyName = String(friend.userFirstname.prefix(1))
            if var nameValues = nameDictionary[keyName] {
                nameValues.append(friend)
                nameDictionary[keyName] = nameValues
            } else {
                nameDictionary[keyName] = [friend]
            }
        }
                
        nameSectionsTitles = [String](nameDictionary.keys)
        nameSectionsTitles = nameSectionsTitles.sorted(by: { $0 < $1 })
        
        self.tableView.reloadData()
    }
    
    
    //MARK: - Table View Data Sours

    override func numberOfSections(in tableView: UITableView) -> Int {
        return nameSectionsTitles.count
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let keyName = nameSectionsTitles[section]
        if let nameValues = nameDictionary[keyName] {
            return nameValues.count
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AllFriends", for: indexPath) as? MyFriendCell else { return UITableViewCell() }
        
        let keyName = nameSectionsTitles[indexPath.section]
        if let nameValues = nameDictionary[keyName] {
            
            cell.FirstnameLabel.text = nameValues[indexPath.row].userFirstname
            cell.LastnameLabel.text = nameValues[indexPath.row].userLastname
            cell.ImageFriend.image = UIImage(named: nameValues[indexPath.row].userImage)
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return nameSectionsTitles[section]
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return nameSectionsTitles
    }
    
    //MARK: - sorting photos by friends
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showPhoto" {
                if let friendPhoto = segue.destination as? PhotoFriendController {
                   let friendIndex = tableView.indexPathForSelectedRow
                    let nameCell = tableView.cellForRow(at: friendIndex!) as! MyFriendCell
                    for friend in myFriendsOld {
                        if nameCell.FirstnameLabel.text == friend.userFirstname {
                            friendPhoto.selectedUser = friend.userPhoto
                            break
                        }
                    }
                }
            }
        }
    
    //MARK: - Exit Button
    
    @IBAction func logOut(unwingSegue: UIStoryboardSegue){
        self.dismiss(animated: true, completion: nil)
    }
}
