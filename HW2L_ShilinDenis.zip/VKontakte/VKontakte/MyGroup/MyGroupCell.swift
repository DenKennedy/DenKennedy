//
//  MyGroupCell.swift
//  VKontakte
//
//  Created by DenKennedy on 21.02.2021.
//

import UIKit

class MyGroupCell: UITableViewCell {

    @IBOutlet weak var MyGroupName: UILabel!
    
    @IBOutlet weak var MyGroupImage: UIImageView!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
