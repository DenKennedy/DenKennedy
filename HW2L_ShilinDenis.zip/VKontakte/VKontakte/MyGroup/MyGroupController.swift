//
//  MyGroupController.swift
//  VKontakte
//
//  Created by DenKennedy on 21.02.2021.
//

import UIKit

class MyGroupController: UITableViewController {

    var myGroups = [String]()
    var myGroupImage = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: - Table View Data Sours

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myGroups.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MyGroupCell", for: indexPath) as? MyGroupCell else { return UITableViewCell() }
        
        cell.MyGroupName.text = myGroups[indexPath.row]
        cell.MyGroupImage.image = UIImage(named: myGroupImage[indexPath.row])
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            myGroups.remove(at: indexPath.row)
            myGroupImage.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    //MARK: - add group to favorites
    
    @IBAction func addGroup(segue: UIStoryboardSegue) {
        if segue.identifier == "addGroup" {
            let allGroupController = segue.source as! AllGroupController
            
            if let indexPath = allGroupController.tableView.indexPathForSelectedRow {
                let group = allGroupController.filtredGroups[indexPath.row].groupName
                let groupImage = allGroupController.filtredGroups[indexPath.row].groupImage
                
                if !myGroups.contains(group) {
                    
                    myGroups.append(group)
                    myGroupImage.append(groupImage)
                    tableView.reloadData()
                }
            }
        }
    }
    
    
    //MARK: - Exit Button
    
    @IBAction func logOut(unwingSegue: UIStoryboardSegue){
        self.dismiss(animated: true, completion: nil)
    }
}
