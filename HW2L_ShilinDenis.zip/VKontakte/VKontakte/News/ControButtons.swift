//
//  ControButtons.swift
//  VKontakte
//
//  Created by DenKennedy on 22.03.2021.
//

import UIKit

@IBDesignable class LikeControlButtons: UIControl {
    
}
