//
//  NewsTableController.swift
//  VKontakte
//
//  Created by DenKennedy on 21.03.2021.
//

import UIKit

class NewsTableController: UITableViewController {
    
    let allNews = [news1, news2]

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return allNews.count
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell", for: indexPath) as? NewsTableViewCell  else { return UITableViewCell() }
        
        cell.Heading.text = allNews[indexPath.row].heading
        cell.PublicationDate.text = allNews[indexPath.row].publicationDate
        cell.NewsImage.image = UIImage(named: allNews[indexPath.row].newsPhoto)
        cell.BodyNews.text = allNews[indexPath.row].bodyNews

        return cell
    }
    
}
