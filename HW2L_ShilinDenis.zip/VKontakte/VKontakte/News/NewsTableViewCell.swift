//
//  NewsTableViewCell.swift
//  VKontakte
//
//  Created by DenKennedy on 21.03.2021.
//

import UIKit

class NewsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var Heading: UILabel!
    @IBOutlet weak var PublicationDate: UILabel!
    @IBOutlet weak var NewsImage: UIImageView!
    @IBOutlet weak var BodyNews: UILabel!
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
