//
//  LikePhoto.swift
//  VKontakte
//
//  Created by DenKennedy on 28.02.2021.
//

import UIKit

class LikePhotoControl: UIControl {
    
    private var labelLikeCount: UILabel!
    private var heartIcon: UIImageView!
    private var likeCount = 0
    
    lazy var tapGestureRecognizer: UITapGestureRecognizer = {
        let recognizer = UITapGestureRecognizer(target: self,action: #selector(onTap))
        recognizer.numberOfTapsRequired = 2
        recognizer.numberOfTouchesRequired = 1
        return recognizer
    }()
    
    @objc func onTap() {
        if likeCount == 0 {
            addLike()
        } else {
            undoLike()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addGestureRecognizer(tapGestureRecognizer)
        self.setupView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        addGestureRecognizer(tapGestureRecognizer)
        self.setupView()
    }
    
    func addLike(){
            likeCount += 1
            labelLikeCount.textColor = .systemRed
            labelLikeCount.text = String(likeCount)
            heartIcon.image = UIImage(named: "heartRed")
    }
        
    func undoLike(){
        likeCount = 0
        labelLikeCount.textColor = .systemBlue
        labelLikeCount.text = String(likeCount)
        heartIcon.image = UIImage(named: "heartShaped")
    }
    
    
    private func setupView() {
        labelLikeCount = UILabel(frame: CGRect(x: 150, y: 175, width: 14, height: 14))
        labelLikeCount.font = labelLikeCount.font.withSize(18)
        labelLikeCount.textColor = .systemBlue
        labelLikeCount.text = String(likeCount)
        self.addSubview(labelLikeCount)

        
        heartIcon = UIImageView(frame: CGRect(x: 158, y: 160, width: 40, height: 40))
        heartIcon.image = UIImage(named: "heartShaped")
        self.addSubview(heartIcon)
    }
 
}


