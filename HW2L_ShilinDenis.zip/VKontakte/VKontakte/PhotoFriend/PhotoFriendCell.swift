//
//  PhotoFriendCell.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

class PhotoFriendCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
}
