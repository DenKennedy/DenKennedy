//
//  PhotoFriendController.swift
//  VKontakte
//
//  Created by DenKennedy on 22.02.2021.
//

import UIKit

class PhotoFriendController: UICollectionViewController {
    
    var selectedUser = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedUser.count
    }
    

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageFriend", for: indexPath) as? PhotoFriendCell else { return UICollectionViewCell() }
        
        cell.imageView.image = UIImage(named: selectedUser[indexPath.row])
    
        return cell
    }
}

