//
//  SessionInfo.swift
//  VKontakte
//
//  Created by DenKennedy on 23.03.2021.
//

import Foundation

class Session {
    static let shared = Session()
    
    
    private init() {
        
    }
    var token: String = ""
    var userID = Int()
    
}
