//
//  WebVkLoginViewController.swift
//  VKontakte
//
//  Created by DenKennedy on 28.03.2021.
//

import UIKit
import WebKit

class WebVkLoginViewController: UIViewController {
    
 
    @IBOutlet weak var WebLogin: WKWebView! {
        didSet{
            WebLogin.navigationDelegate = self
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var components = URLComponents()
        components.scheme = "https"
        components.host = "oauth.vk.com"
        components.path = "/authorize"
        components.queryItems = [
            URLQueryItem(name: "client_id", value: "7805163"),
            URLQueryItem(name: "scope", value: "262150"),
            URLQueryItem(name: "display", value: "mobile"),
            URLQueryItem(name: "redirect_uri", value: "https://oauth.vk.com/blank.html"),
            URLQueryItem(name: "response_type", value: "token"),
            URLQueryItem(name: "v", value: "5.130")
        ]
        
        guard let url = components.url else {
            return
        }
        
        let request = URLRequest(url: url)
        WebLogin.load(request)
        
    }
}

extension WebVkLoginViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        
        
        guard let url = navigationResponse.response.url,
              url.path == "/blank.html",
              let fragment = url.fragment else {
            decisionHandler(.allow)
            return
        }
                
        let parametrs = fragment
            .components(separatedBy: "&")
            .map { $0.components(separatedBy: "=") }
            .reduce([String: String]()) { result, parametr in
                var dictionary = result
                let key = parametr[0]
                let value = parametr[1]
                dictionary[key] = value
                
                return dictionary
            }
        
        guard let token = parametrs["access_token"],
              let userIdString = parametrs["user_id"],
              let _ = Int(userIdString) else {
            decisionHandler(.allow)
            
            return
        }
        
        Session.shared.token = token
        
        print("Это токен \(token)")

        NetworkManager.shared.loadGroups(token: token)
        NetworkManager.shared.loadFriends(token: token)
        NetworkManager.shared.loadPhotos(token: token)

        decisionHandler(.cancel)
    }
}
